execute if entity @e[nbt={InLove:0},distance=..1] unless entity @e[nbt={Age:0},distance=..1] run function golden_dandelion_backport:baby_found


execute unless entity @e[nbt={InLove:0},distance=..1] if entity @e[type=player,distance=..4] positioned ^ ^ ^0.2 run function golden_dandelion_backport:golden_dandelion_raycast