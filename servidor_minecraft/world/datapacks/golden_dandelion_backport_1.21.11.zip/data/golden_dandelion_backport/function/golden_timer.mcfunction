execute as @a[scores={golden_dandelion_cooldown=1..}] run scoreboard players remove @s golden_dandelion_cooldown 1

execute if entity @a[scores={golden_dandelion_cooldown=1..}] run schedule function golden_dandelion_backport:golden_timer 1t replace