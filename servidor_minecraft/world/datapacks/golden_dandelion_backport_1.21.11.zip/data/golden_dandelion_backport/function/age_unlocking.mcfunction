execute at @s run clear @n[type=minecraft:player,nbt={Inventory:[{id:"minecraft:music_disc_13"}]},distance=..5] minecraft:music_disc_13[minecraft:custom_data="{golden_dandelion: true}"] 1

data merge entity @s {Age:-24000}


tag @s remove golden_dandelion_locked

