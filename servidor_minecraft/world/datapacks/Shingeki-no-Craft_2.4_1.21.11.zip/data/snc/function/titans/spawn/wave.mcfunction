#> snc:titans/spawn/wave
# Spawns 1 wave of pure titans
#
# @input
#   Runs every second with a 20% of chance
#
# @output
#   k pure titans

execute store result score @s random run random value 1..100
execute if score @s random > $titan_spawn_rate config run return 1
execute if score @s snc.time matches 0..90 run return 1
execute if score $titan_max_wave config matches 1 run scoreboard players set @s random 1
execute if score $titan_max_wave config matches 2 store result score @s random run random value 1..2
 execute if score $titan_max_wave config matches 3 store result score @s random run random value 1..3
 execute if score $titan_max_wave config matches 4 store result score @s random run random value 1..4
 execute if score $titan_max_wave config matches 5 store result score @s random run random value 1..5

execute if score @s random matches 1.. run function snc:titans/spawn/rate