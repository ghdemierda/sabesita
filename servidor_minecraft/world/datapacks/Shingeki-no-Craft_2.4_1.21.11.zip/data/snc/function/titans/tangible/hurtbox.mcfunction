execute unless entity @s[team=titan] run team join titan

## Koniglich
execute if score @s snc.gene.koniglich matches 1 run function snc:eldia/koniglich
# kill if its not on body
execute unless predicate snc:is_riding run function snc:logic/kill_mob

# If is under unluck -> kill
execute if predicate snc:titan/kill run function snc:titans/kill