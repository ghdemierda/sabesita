execute if score @s atk matches 70 run tag @s add snc.titan.attack
execute if score @s atk matches 70 on vehicle run effect give @s slowness 2 127 true

execute if score @s atk matches 140 run tag @s add snc.titan.attack
execute if score @s atk matches 140 on vehicle run effect give @s slowness 2 127 true