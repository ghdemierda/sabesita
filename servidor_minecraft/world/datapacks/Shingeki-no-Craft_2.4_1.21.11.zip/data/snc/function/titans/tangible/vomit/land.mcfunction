summon area_effect_cloud ~ ~-.5 ~ {custom_particle:{type:"dust",scale:.01,color:[0,0,0]},ReapplicationDelay:0,Radius:2f,Duration:60,Effects:[{Id:2,Amplifier:5b,Duration:40,ShowParticles:0b}]}
particle block{block_state:"redstone_block"} ~ ~ ~ 1 1.5 1 1 300 force
kill