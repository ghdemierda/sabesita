# Range
execute on vehicle unless function snc:titans/mobs/zick/attack/1_trigger run return -1
tag @s add snc.titan.attack

execute on vehicle run effect give @s slowness 1 6 true