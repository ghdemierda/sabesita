tp @s[tag=!transform] ~ ~ ~
effect give @s levitation 1 0 true