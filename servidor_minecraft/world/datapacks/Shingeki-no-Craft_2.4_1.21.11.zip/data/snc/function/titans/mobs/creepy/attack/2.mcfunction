# Range
execute on vehicle unless function snc:titans/mobs/creepy/attack/2_trigger run return -1
tag @s add snc.titan.attack

execute on vehicle at @s rotated ~ -15 run function snc:logic/motion/self/creepy with entity @s