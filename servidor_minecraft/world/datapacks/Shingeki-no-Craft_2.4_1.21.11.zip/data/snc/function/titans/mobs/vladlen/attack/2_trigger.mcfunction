## Trigger animation
execute on target if entity @s[distance=..16] run return 1