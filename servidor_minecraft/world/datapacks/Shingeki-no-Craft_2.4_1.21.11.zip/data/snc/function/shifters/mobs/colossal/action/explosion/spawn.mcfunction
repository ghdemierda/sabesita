advancement grant @s only snc:shifters/colossal/nuke
$scoreboard players remove $energy $(shifter)_vars 1800

# Example usage
#/function snc:shifters/mobs/colossal/action/explosion/spawn {shifter:"blank",explosion_size_colossal:7, explosion_size_passive:5, explosion_size:4}
# If has colossal full passive
$execute if predicate snc:shifters/colossal/full run function snc:shifters/mobs/colossal/action/explosion/summon {size:$(explosion_size_colossal)}
$execute if predicate snc:shifters/colossal/full as @a[distance=..$(explosion_size_colossal)0] run function snc:shifters/mobs/colossal/action/explosion/flash
# If has passive but is not female
$execute unless predicate snc:shifters/colossal/full if entity @s[tag=snc.shifter.colossal] run function snc:shifters/mobs/colossal/action/explosion/summon {size:$(explosion_size_passive)}
# If doesn't have passive
$execute unless entity @s[tag=snc.shifter.colossal] run summon item_display ~ ~-$(explosion_size) ~ {brightness:{sky:0,block:15},item_display:"head",Tags:["shifter","snc.nuke","snc.base"],view_range:128f,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[10f,10f,10f]},item:{id:"minecraft:turtle_scute",count:1b,components:{"minecraft:item_model":"minecraft:air","custom_data":{size:$(explosion_size), fade1:0, fade2:0, fade3:0}}}}

effect give @s resistance 30 127 true