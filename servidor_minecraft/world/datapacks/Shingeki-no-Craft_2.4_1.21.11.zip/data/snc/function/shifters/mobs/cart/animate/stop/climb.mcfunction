execute if score walk cart_vars matches 20 run data modify entity @s item.components.minecraft:item_model set value "shifters/cart/climb/1"
execute if score walk cart_vars matches 20 run playsound minecraft:snc.shifters.jaw.climb neutral @a ~ ~ ~ 2 1
execute if score walk cart_vars matches 15 run data modify entity @s item.components.minecraft:item_model set value "shifters/cart/climb/2"
execute if score walk cart_vars matches 10 run data modify entity @s item.components.minecraft:item_model set value "shifters/cart/climb/3"
execute if score walk cart_vars matches 10 run playsound minecraft:snc.shifters.jaw.climb neutral @a ~ ~ ~ 2 1
execute if score walk cart_vars matches 5 run data modify entity @s item.components.minecraft:item_model set value "shifters/cart/climb/4"

scoreboard players set $climb cart_vars 1
execute on vehicle run attribute @s minecraft:scale base set 1.5
return 1