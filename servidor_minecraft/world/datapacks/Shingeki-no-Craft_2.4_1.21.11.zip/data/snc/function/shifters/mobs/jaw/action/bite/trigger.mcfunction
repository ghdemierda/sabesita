advancement revoke @s only snc:shifters/jaw/bite
# Restart moves
give @s quartz[minecraft:custom_data={atk_shifter:1b,6_titan:1b},minecraft:item_model="item/blank"]

execute on vehicle on passengers if entity @s[tag=aj.jaw.root,tag=!aj.jaw.animation.bite.playing] run function snc:shifters/mobs/jaw/animate/bite