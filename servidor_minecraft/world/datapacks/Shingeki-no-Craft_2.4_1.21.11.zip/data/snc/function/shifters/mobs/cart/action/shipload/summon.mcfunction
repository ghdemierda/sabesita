execute if score $shipload cart_vars matches 1 run function snc:shifters/mobs/cart/action/shipload/barrels/spawn
execute if score $shipload cart_vars matches 2 run function snc:shifters/mobs/cart/action/shipload/turrets/spawn
scoreboard players set $shipload cart_vars 0