#execute on vehicle on passengers if entity @s[tag=aj.cart.root] on vehicle on passengers if entity @s[tag=cart.case] run rotate @s ~ -90

ride @s mount 0000007f-0000-007f-0000-007f00000001
execute on vehicle run effect give @s slowness 2 3 true

# Set model
execute if score $climb cart_vars matches 0 run data merge entity @s {transformation:{translation:[0f,0f,0f]}}
execute if score $climb cart_vars matches 1 run data merge entity @s {transformation:{translation:[0f,0f,1.6f]}}