playsound minecraft:snc.shifters.jaw.roar player @a ~ ~ ~ 12 1.6
return 1