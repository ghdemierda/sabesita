# Temporal, rework in the future
function snc:shifters/mobs/armor/action/hardening/break
function snc:shifters/mobs/armor/action/hardening/break
function snc:shifters/mobs/armor/action/hardening/break