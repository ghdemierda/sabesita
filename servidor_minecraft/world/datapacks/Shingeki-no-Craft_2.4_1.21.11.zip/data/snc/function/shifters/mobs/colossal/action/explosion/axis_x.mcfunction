$execute if score $pair snc.titan.explosion matches 0 rotated ~ $(angle_y) positioned ^ ^ ^$(radius) run function snc:shifters/mobs/colossal/action/explosion/boom
$execute if score $pair snc.titan.explosion matches 1 rotated ~ $(angle_y) rotated ~ ~15 positioned ^ ^ ^$(radius) run function snc:shifters/mobs/colossal/action/explosion/boom

$scoreboard players remove @s snc.rotation_x $(angle_x)

$execute if score @s snc.rotation_x matches 1.. rotated ~$(angle_x) $(angle_y) run function snc:shifters/mobs/colossal/action/explosion/axis_x with entity @s item.components."minecraft:custom_data"