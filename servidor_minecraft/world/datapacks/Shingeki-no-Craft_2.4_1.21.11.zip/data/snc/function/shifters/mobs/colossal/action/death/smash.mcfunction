scoreboard players add @a[distance=..128] earthquake 16
playsound aot.rock_smash master @a ^ ^ ^40 6 .1

tag @s remove snc.colossal.smash