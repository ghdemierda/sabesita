function animated_java:jaw/animations/death/play
scoreboard players set $hold jaw_vars 0
scoreboard players set state jaw_vars 9