function animated_java:jaw/animations/idle/play
execute on vehicle run attribute @s scale base set 1.25