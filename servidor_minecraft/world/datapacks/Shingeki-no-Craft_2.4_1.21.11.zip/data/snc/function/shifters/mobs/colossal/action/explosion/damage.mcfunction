execute at @s if score $shifter_griefing config matches 1 run function snc:shifters/mobs/colossal/action/steam/fire
playsound minecraft:aot.huge_explosion player @s ~ ~ ~ 10 1
scoreboard players add @s earthquake 9

damage @s[tag=transform,predicate=!snc:shifters/colossal/score] 12 on_fire
damage @s[tag=!transform] 12 on_fire
effect give @s[tag=hurtbox] unluck 1 0 true

execute at @s[tag=!transform] run function snc:player/odm/impulse/push {"power":3, "x":"^", "y":"^-.05", "z":"^1"}