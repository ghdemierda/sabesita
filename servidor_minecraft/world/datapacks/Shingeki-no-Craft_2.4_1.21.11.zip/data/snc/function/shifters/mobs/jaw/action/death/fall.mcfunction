# Tp player to neck
execute as @p[scores={jaw_vars=1},tag=!transform,distance=..30] rotated ~ 0 run tp ^ ^4 ^-1

# Start riding armor_stand instead of horse
execute on vehicle run kill
ride @s dismount

summon armor_stand ^ ^ ^ {DisabledSlots:4144959,Invisible:1b,Tags:["snc.shifter.jaw","dead","shifter"],Pose:{Head:[-20f,10f,15f]},equipment:{head:{id:"minecraft:white_dye",count:1b,components:{"minecraft:item_model":"shifters/jaw/bite/decay/1"}}},attributes:[{id:"minecraft:scale",base:2.1}]}

ride @s mount @n[type=armor_stand,tag=dead]
execute on vehicle run rotate @s ~ 0