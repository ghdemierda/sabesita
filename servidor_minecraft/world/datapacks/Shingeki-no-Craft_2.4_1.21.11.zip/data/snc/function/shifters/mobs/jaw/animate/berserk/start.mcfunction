effect give @s absorption 20 0 true
clear @s
execute on vehicle on passengers if entity @s[tag=aj.jaw.root] run function animated_java:jaw/animations/berserk_start/play
execute on vehicle run effect give @s slowness 2 127 true
execute on vehicle run effect give @s speed infinite 2 true
execute on vehicle run attribute @s minecraft:scale base set .5
particle minecraft:cloud ~ ~ ~ 1 3 1 1 512 force
playsound minecraft:aot.steam player @a ~ ~ ~ 4 1
scoreboard players set state jaw_vars 1
scoreboard players set $energy jaw_vars 3600
scoreboard players set $berserk jaw_vars 0
return 1