## ALWAYS Remove when dead
execute if score state cart_vars matches 9 if function snc:shifters/mobs/cart/action/shipload/remove run return -1
execute unless score state cart_vars matches 0.. if function snc:shifters/mobs/cart/action/shipload/remove run return -1

# Hitbox
execute if entity @s[tag=aj.cart.locator.consume] on passengers run function snc:shifters/mobs/cart/action/hold/effects

# Rotate pivot
execute if entity @s[tag=cart.case] run function snc:shifters/mobs/cart/action/shipload/case
# Turrets Controller
execute if entity @s[tag=cart.turret.1] on passengers if data entity @s[type=interaction] interaction run function snc:interact/turret {"turret":1}
execute if entity @s[tag=cart.turret.2] on passengers if data entity @s[type=interaction] interaction run function snc:interact/turret {"turret":2}
execute if entity @s[tag=cart.turret.3] on passengers if data entity @s[type=interaction] interaction run function snc:interact/turret {"turret":3}

# Is climbing
execute if score $climb cart_vars matches 1 rotated as 0000007f-0000-007f-0000-008100000001 positioned ^ ^-1 ^2.5 if function snc:shifters/mobs/cart/action/shipload/climb run return -1

# Is not climbing
execute rotated as 0000007f-0000-007f-0000-008100000001 run function snc:shifters/mobs/cart/action/shipload/climb