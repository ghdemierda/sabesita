## Variants
scoreboard players operation $prev_variant jaw_vars = $variant jaw_vars
execute if score $health jaw_vars matches 20.. run scoreboard players set $variant jaw_vars 0
execute if score $health jaw_vars matches 15..19 run scoreboard players set $variant jaw_vars 1
execute if score $health jaw_vars matches 10..16 run scoreboard players set $variant jaw_vars 2
execute if score $health jaw_vars matches 0..9 run scoreboard players set $variant jaw_vars 3

# Prevent re-apply variant
execute if score $prev_variant jaw_vars = $variant jaw_vars run return -1

# If current health is more than previous
execute unless score $health jaw_vars < $prev_health jaw_vars run particle minecraft:dust_color_transition{from_color:[1f, 0.941f, 0.098f],to_color:[1f, 1f, 1f], scale:2f} ^ ^2 ^-1 1.5 1.5 1.5 1 64 force
execute unless score $health jaw_vars < $prev_health jaw_vars run playsound minecraft:aot.steam player @a ~ ~4 ~ 4 2

execute if score $variant jaw_vars matches 0 if function animated_java:jaw/variants/default/apply run return -1
execute if score $variant jaw_vars matches 1 if function animated_java:jaw/variants/decay1/apply run return -1
execute if score $variant jaw_vars matches 2 if function animated_java:jaw/variants/decay2/apply run return -1
execute if score $variant jaw_vars matches 3 if function animated_java:jaw/variants/decay3/apply run return -1