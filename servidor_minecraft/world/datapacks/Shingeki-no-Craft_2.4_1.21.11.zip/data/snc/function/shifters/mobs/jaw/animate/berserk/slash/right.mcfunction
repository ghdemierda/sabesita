function animated_java:jaw/animations/berserk_leap_r/play
scoreboard players set state jaw_vars 14
scoreboard players set $combo_ber jaw_vars -1

execute on vehicle run attribute @s scale base set .5
execute on vehicle run effect give @s slowness 1 6 true

execute on vehicle positioned as @s rotated ~ 0 run function snc:logic/motion/generic {"score":"jaw_vars","strength":0.05, "unstoppable":"false"}
return 1