# If doesn't have hardening, can't climb
execute unless score $set_hardening cart_vars matches 1 if function snc:shifters/mobs/cart/animate/stop/walk run return -1

execute on vehicle at @s rotated ~ 0 run function snc:shifters/mobs/cart/action/movement/check_wall
execute if score $wall cart_vars matches 1 on vehicle positioned as @s on passengers if entity @s[tag=transform] rotated as @s on vehicle rotated ~ -40 run function snc:logic/motion/generic {"score":"cart_vars","strength":0.006, "unstoppable":"false"}
execute if score $wall cart_vars matches 2..3 on vehicle positioned as @s on passengers if entity @s[tag=transform] rotated as @s on vehicle rotated ~ -60 run function snc:logic/motion/generic {"score":"cart_vars","strength":0.006, "unstoppable":"false"}

# Play climb animation
execute if score $wall cart_vars matches 1.. run function snc:shifters/mobs/cart/animate/stop/climb
# Play run
execute unless score $wall cart_vars matches 1.. run function snc:shifters/mobs/cart/animate/stop/walk

return 1