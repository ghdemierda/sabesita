execute if score $air jaw_vars matches 0 on vehicle at @s run function snc:shifters/mobs/jaw/action/movement/step
execute on vehicle at @s if block ~ ~-4 ~ #snc:tangible run return -1
execute if score $air jaw_vars matches 1 if score $air_frame jaw_vars matches 0..12 run function snc:shifters/mobs/jaw/animate/jump_loop