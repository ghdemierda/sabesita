scoreboard players add @s colossal_vars 1
# Init
$execute if score @s colossal_vars matches 1 run scoreboard players set #fade colossal_vars $(size)00
execute if score @s colossal_vars matches 1 run function snc:shifters/mobs/colossal/action/explosion/init
# Mush
$execute if entity @s[tag=snc.top] if score @s colossal_vars matches 5 run data merge entity @s {view_range:128f,start_interpolation:0,interpolation_duration:$(size)00,teleport_duration:2,transformation:{translation:[0f,$(size)5f,0f],scale:[$(size)0f,$(size)0f,$(size)0f]}}
$execute if entity @s[tag=snc.base] if score @s colossal_vars matches 5 run data merge entity @s {view_range:128f,start_interpolation:0,interpolation_duration:$(size)00,teleport_duration:2,transformation:{translation:[0f,0f,0f],scale:[$(size)0f,$(size)0f,$(size)0f]}}
$execute if entity @s[tag=snc.wave.1] if score @s colossal_vars matches 5 run data merge entity @s {view_range:128f,start_interpolation:0,interpolation_duration:$(size)00,teleport_duration:2,transformation:{translation:[0f,$(size)9f,0f],scale:[$(size)0f,1f,$(size)0f]}}
execute if entity @s[tag=snc.wave.1] run rotate @s ~-1 ~
$execute if entity @s[tag=snc.wave.2] if score @s colossal_vars matches 5 run data merge entity @s {view_range:128f,start_interpolation:0,interpolation_duration:$(size)00,teleport_duration:2,transformation:{translation:[0f,$(size)6f,0f],scale:[$(size)5f,1f,$(size)9f]}}
execute if entity @s[tag=snc.wave.2] run rotate @s ~1 ~


# Explosion
$execute if entity @s[tag=snc.base] unless score @s snc.titan.explosion matches $(size).. positioned ~ ~32 ~ run function snc:shifters/mobs/colossal/action/explosion/rate
$execute if entity @s[tag=snc.base] run kill @e[type=item,distance=..$(size)0]

# Vanish
$execute as @s[tag=snc.top,tag=snc.shifter.colossal] if score @s colossal_vars matches $(fade1) run data merge entity @s {item:{components:{"minecraft:item_model":"shifters/colossal/explosion/2/top"}}}
$execute as @s[tag=snc.base,tag=snc.shifter.colossal] if score @s colossal_vars matches $(fade1) run data merge entity @s {item:{components:{"minecraft:item_model":"shifters/colossal/explosion/2/base"}}}
$execute as @s[tag=snc.top,tag=snc.shifter.colossal] if score @s colossal_vars matches $(fade2) run data merge entity @s {item:{components:{"minecraft:item_model":"shifters/colossal/explosion/3/top"}}}
$execute as @s[tag=snc.base,tag=snc.shifter.colossal] if score @s colossal_vars matches $(fade2) run data merge entity @s {item:{components:{"minecraft:item_model":"shifters/colossal/explosion/3/base"}}}

$execute if score @s colossal_vars matches $(fade1) run data merge entity @s {brightness:{sky:0,block:13}}
$execute if score @s colossal_vars matches $(fade2) run data merge entity @s {brightness:{sky:0,block:10}}
$execute if score @s colossal_vars matches $(fade3) run kill