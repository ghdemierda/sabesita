function snc:shifters/mobs/colossal/action/death/fall
scoreboard players set $hold colossal_vars 0
scoreboard players set state colossal_vars 9