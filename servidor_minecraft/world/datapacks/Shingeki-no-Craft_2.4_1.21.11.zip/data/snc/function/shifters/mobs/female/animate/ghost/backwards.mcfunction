function animated_java:female/animations/ghost_back/play
scoreboard players set state female_vars 16
execute on vehicle run attribute @s minecraft:scale base set 3

return 1