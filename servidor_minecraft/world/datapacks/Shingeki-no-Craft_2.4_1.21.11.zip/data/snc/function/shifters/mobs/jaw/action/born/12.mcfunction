execute on vehicle on passengers if entity @s[tag=transform] run function snc:shifters/mobs/jaw/head {"frame":2}
execute positioned ~ ~3 ~ run function snc:titans/volt/spawn
scoreboard players set shift.regen jaw_vars 100000