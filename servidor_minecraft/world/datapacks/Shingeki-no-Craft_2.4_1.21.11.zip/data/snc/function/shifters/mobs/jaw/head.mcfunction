## Jaw
$execute if entity @s[tag=snc.shifter.jaw] run function snc:shifters/mobs/head {"shifter":"jaw", "type":"default", "custom_data":{}, "frame":$(frame)}
# Berserk
$execute if entity @s[tag=snc.shifter.jaw,tag=snc.shifter.attack] if score $berserk jaw_vars matches 0 run function snc:shifters/mobs/head {"shifter":"jaw", "type":"default", "custom_data":{berserk:1b}, "frame":$(frame)}