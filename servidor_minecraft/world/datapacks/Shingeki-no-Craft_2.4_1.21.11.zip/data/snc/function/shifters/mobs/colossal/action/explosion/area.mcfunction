# Start wave in bottom
execute unless score @s snc.rotation_y matches -89.. run scoreboard players set @s snc.rotation_y 90
# Sound delay
execute if score @s snc.rotation_y matches 90 if score @s snc.titan.explosion matches 1 as @e[type=!#snc:pivot,distance=..32] run function snc:shifters/mobs/colossal/action/explosion/damage
execute if score @s snc.rotation_y matches 90 if score @s snc.titan.explosion matches 2 as @e[type=!#snc:pivot,distance=33..64] run function snc:shifters/mobs/colossal/action/explosion/damage
execute if score @s snc.rotation_y matches 90 if score @s snc.titan.explosion matches 3 as @e[type=!#snc:pivot,distance=65..96] run function snc:shifters/mobs/colossal/action/explosion/damage
execute if score @s snc.rotation_y matches 90 if score @s snc.titan.explosion matches 4 as @e[type=!#snc:pivot,distance=97..128] run function snc:shifters/mobs/colossal/action/explosion/damage
execute if score @s snc.rotation_y matches 90 if score @s snc.titan.explosion matches 5 as @e[type=!#snc:pivot,distance=129..] run playsound minecraft:aot.huge_explosion player @s ~ ~ ~ 10 1

# Estimate angle
# 2160 = 360 * 6
#scoreboard players set @s snc.rotation_x 2880
#scoreboard players operation @s snc.rotation_x /= #360 constant
#scoreboard players operation @s snc.rotation_x *= @s snc.titan.explosion
#tellraw @a {"score":{"name":"$angle","objective":"snc.titan.explosion"}}
execute unless score @s snc.titan.explosion matches 1.. run scoreboard players set @s snc.rotation_x 45
execute if score @s snc.titan.explosion matches 1..2 run scoreboard players set @s snc.rotation_x 45
execute if score @s snc.titan.explosion matches 3..5 run scoreboard players set @s snc.rotation_x 45
execute if score @s snc.titan.explosion matches 6..14 run scoreboard players set @s snc.rotation_x 30
execute if score @s snc.titan.explosion matches 15.. run scoreboard players set @s snc.rotation_x 20

scoreboard players operation $pair snc.titan.explosion = @s snc.titan.explosion
scoreboard players operation $pair snc.titan.explosion %= #2 constant
#tellraw @a {"score":{"name":"$pair","objective":"snc.titan.explosion"}}

# Rotate next cycle
scoreboard players operation @s snc.rotation_y -= @s snc.rotation_x
# Increase wave if cycle ended
execute if score @s snc.rotation_y matches ..-90 run scoreboard players add @s snc.titan.explosion 1
execute if score @s snc.rotation_y matches ..-90 run return 1

# Distance between explosions
scoreboard players operation $radius snc.titan.explosion = @s snc.titan.explosion
scoreboard players operation $radius snc.titan.explosion *= #5 constant
scoreboard players operation $radius snc.titan.explosion += #5 constant

execute store result entity @s item.components."minecraft:custom_data".angle_x int 1 run scoreboard players get @s snc.rotation_x
execute store result entity @s item.components."minecraft:custom_data".angle_y int 1 run scoreboard players get @s snc.rotation_y
execute store result entity @s item.components."minecraft:custom_data".radius int 1 run scoreboard players get $radius snc.titan.explosion

# Explode
scoreboard players set @s snc.rotation_x 360
execute if score $pair snc.titan.explosion matches 0 rotated ~15 0 run function snc:shifters/mobs/colossal/action/explosion/axis_x with entity @s item.components."minecraft:custom_data"
execute if score $pair snc.titan.explosion matches 1 rotated ~ 0 run function snc:shifters/mobs/colossal/action/explosion/axis_x with entity @s item.components."minecraft:custom_data"