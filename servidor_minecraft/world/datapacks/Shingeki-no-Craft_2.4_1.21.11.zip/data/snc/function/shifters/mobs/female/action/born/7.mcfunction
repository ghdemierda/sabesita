execute on vehicle on passengers if entity @s[tag=transform] run item replace entity @s armor.head with white_dye[minecraft:item_model="shifters/female/bite/decay/4"]

execute on vehicle run effect clear @s levitation