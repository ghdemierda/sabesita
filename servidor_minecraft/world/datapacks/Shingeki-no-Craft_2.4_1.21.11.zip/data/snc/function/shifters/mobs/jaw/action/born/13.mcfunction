execute on vehicle on passengers if entity @s[tag=transform] run function snc:shifters/mobs/jaw/head {"frame":3}
scoreboard players set shift.regen jaw_vars 100000