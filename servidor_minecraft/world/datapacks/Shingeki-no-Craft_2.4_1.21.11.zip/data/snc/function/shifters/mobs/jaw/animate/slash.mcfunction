function animated_java:jaw/animations/slash/play
scoreboard players set state jaw_vars 14