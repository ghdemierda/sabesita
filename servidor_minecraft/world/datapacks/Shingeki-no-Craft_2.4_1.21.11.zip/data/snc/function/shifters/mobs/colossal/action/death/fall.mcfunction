# Tp player to neck
execute as @p[scores={colossal_vars=1},tag=!transform,distance=..30] rotated ~ 0 run tp ^ ^7 ^-1

# Start riding armor_stand instead of horse
execute on vehicle run kill
ride @s dismount

execute if score $form colossal_vars matches 1 rotated ~180 0 run summon armor_stand ^ ^ ^ {DisabledSlots:4144959,Invisible:1b,Tags:["snc.shifter.colossal","snc.colossal.smash","dead","shifter"]}
execute if score $form colossal_vars matches 0 rotated ~180 0 run summon armor_stand ^ ^ ^ {DisabledSlots:4144959,Invisible:1b,Tags:["snc.shifter.colossal","snc.colossal.smash","dead","shifter","snc.colossal.half"]}
ride @s mount @n[type=armor_stand,tag=dead]
#execute on vehicle run tp @s ~ ~ ~ ~180 0