playsound minecraft:snc.shifters.cart.roar player @a ~ ~ ~ 12 1.8
return 1