advancement revoke @s only snc:shifters/jaw/slash
# Restart moves
give @s quartz[minecraft:custom_data={atk_shifter:1b,6_titan:1b},minecraft:item_model="item/blank"]

# If config is enabled AND is in berserk mode then skip
execute if score $shifter_berserk config matches 1 if score $berserk jaw_vars matches 0 if function snc:shifters/mobs/jaw/action/slash/berserk/trigger run return -1

execute on vehicle on passengers if entity @s[tag=aj.jaw.root,tag=!aj.jaw.animation.slash.playing] run function snc:shifters/mobs/jaw/animate/slash