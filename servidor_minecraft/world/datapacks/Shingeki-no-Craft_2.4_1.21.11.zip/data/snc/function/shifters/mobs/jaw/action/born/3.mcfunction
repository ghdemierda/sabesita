execute on vehicle on passengers if entity @s[tag=transform] run item replace entity @s armor.head with white_dye[minecraft:item_model="shifters/jaw/bite/decay/9"]
execute positioned ~ ~3 ~ run function snc:titans/volt/spawn
scoreboard players set shift.regen jaw_vars 100000