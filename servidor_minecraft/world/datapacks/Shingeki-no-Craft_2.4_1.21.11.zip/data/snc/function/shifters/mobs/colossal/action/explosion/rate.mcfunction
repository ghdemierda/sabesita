scoreboard players operation $rate snc.titan.explosion = @s colossal_vars
execute unless score @s snc.titan.explosion matches 1.. run scoreboard players operation $rate snc.titan.explosion %= #2 constant
execute if score @s snc.titan.explosion matches 1..2 run scoreboard players operation $rate snc.titan.explosion %= #2 constant
execute if score @s snc.titan.explosion matches 3..5 run scoreboard players operation $rate snc.titan.explosion %= #10 constant
execute if score @s snc.titan.explosion matches 6..12 run scoreboard players operation $rate snc.titan.explosion %= #15 constant
execute if score @s snc.titan.explosion matches 13.. run scoreboard players operation $rate snc.titan.explosion %= $titan_explosion_rate config

# Controls how often the explosion occurss... Prevents lag, can be configurable
execute if score $rate snc.titan.explosion matches 0 run function snc:shifters/mobs/colossal/action/explosion/area