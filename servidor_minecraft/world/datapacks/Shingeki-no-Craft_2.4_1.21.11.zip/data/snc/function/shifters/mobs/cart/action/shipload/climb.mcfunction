## Barrels
execute if entity @s[tag=cart.barrel.1] unless score state cart_vars matches 2 run tp ^.82 ^4.1 ^-2.3
execute if entity @s[tag=cart.barrel.2] unless score state cart_vars matches 2 run tp ^-.82 ^4.1 ^-2.3
execute if entity @s[tag=cart.barrel.3] unless score state cart_vars matches 2 run tp ^.82 ^4.1 ^-3.95
execute if entity @s[tag=cart.barrel.4] unless score state cart_vars matches 2 run tp ^-.82 ^4.1 ^-3.95

## Turrets
execute if entity @s[tag=cart.turret.1] run function snc:shifters/mobs/cart/action/shipload/turrets/main {"x":1.3,"y":5.3,"z":-2,"turret":1,"rotate":315}
execute if entity @s[tag=cart.turret.2] run function snc:shifters/mobs/cart/action/shipload/turrets/main {"x":-1.3,"y":5.3,"z":-2,"turret":2,"rotate":45}
execute if entity @s[tag=cart.turret.3] run function snc:shifters/mobs/cart/action/shipload/turrets/main {"x":"","y":4.7,"z":-5,"turret":3,"rotate":180}

return 1