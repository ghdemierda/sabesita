execute store result entity @s item.components."minecraft:custom_data".fade1 int 1 run scoreboard players get #fade colossal_vars
scoreboard players add #fade colossal_vars 400
execute store result entity @s item.components."minecraft:custom_data".fade2 int 1 run scoreboard players get #fade colossal_vars
scoreboard players add #fade colossal_vars 400
execute store result entity @s item.components."minecraft:custom_data".fade3 int 1 run scoreboard players get #fade colossal_vars