playsound minecraft:aot.flash player @s ~ ~ ~ 16 .98
title @s title {"text":"\uE001"}
title @s subtitle ""
title @s times 10 20 110