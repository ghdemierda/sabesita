fill ~13 ~13 ~13 ~-13 ~-13 ~-13 mud replace #snc:tangible
fill ~9 ~9 ~9 ~-9 ~-9 ~-9 pale_moss_block replace #snc:tangible
fill ~9 ~9 ~9 ~-9 ~-9 ~-9 air replace #snc:liquid
fillbiome ~15 ~15 ~15 ~-15 ~-15 ~-15 snc:radiation

particle explosion ~ ~ ~ 0 0 0 1 1 force

execute unless score @s snc.titan.explosion matches 1 if predicate snc:chance/30 run summon falling_block ~ ~1 ~ {BlockState:{Name:"minecraft:mud"},Time:1}
execute unless score @s snc.titan.explosion matches 1 if predicate snc:chance/30 run summon falling_block ~ ~ ~ {BlockState:{Name:"minecraft:fire"},Time:1}
setblock ~ ~1 ~ mud
summon fireball ~ ~2 ~ {Tags:["shifter","snc.nuke"],ExplosionPower:13b,Motion:[0.0d,-10.0d,0.0d]}