playsound minecraft:snc.shifters.colossal.roar player @a ~ ~ ~ 12 1.6
return 1