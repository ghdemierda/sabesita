function snc:shifters/mobs/decay

execute if entity @s[tag=!snc.colossal.half] run particle minecraft:cloud ^ ^ ^40 3 3 3 .25 256 force
execute if entity @s[tag=!snc.colossal.half] run playsound minecraft:aot.steam player @a ^ ^ ^40 8 2

execute if entity @s[tag=snc.colossal.half] run particle minecraft:cloud ^ ^ ^ 1.5 1.5 1.5 .25 128 force
execute if entity @s[tag=snc.colossal.half] run playsound minecraft:aot.steam player @a ^ ^ ^ 8 2